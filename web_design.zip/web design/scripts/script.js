let switch1 = false;
let visible = false;
let switchWidth = 640;

window.addEventListener('resize',function(){
    console.log(screen.width);
    if(screen.width>switchWidth){
        if(window.innerWidth > switchWidth) {
            document.getElementById("navlinky").style.display = "inline";
        }else{
            if(switch1===false){
                document.getElementById("navlinky").style.display = "none";
            }else if(switch1===true){
                document.getElementById("navlinky").style.display = "block";
            }
        }
   }
   if(screen.width<=switchWidth) {
       if(switch1===false){
           document.getElementById("navlinky").style.display = "none";
       }else if(switch1===true){
           document.getElementById("navlinky").style.display = "block";
       }
   }
});

function switchMenu(){
    if(switch1===false) {
        document.getElementById("navlinky").style.display = "block";
        switch1=true;
    }else{
        document.getElementById("navlinky").style.display = "none";
        switch1=false;
    }
}

function switchSearch(){
    if(screen.width > switchWidth){
        location.href = "search.html";
    }
    else if(visible === false){
        visible = true;
        document.getElementById("searchBar").style.display = "inline";
    }
    else if(visible === true) {
        location.href = "search.html";
    }
}